#=======================================================================================
#
# File:        InstallPackages.R
# Authors:     Dave Langer
# Description: This code was written as part of the 1-day course "Hands-on: Machine 
#              Learning Made Easy - No, Really!" 
#
# NOTE - This file is provided "As-Is" and no warranty regarding its contents is
#        offered nor implied. USE AT YOUR OWN RISK!
#
#=======================================================================================


# Install packages required for the course.
install.packages(c("rpart", "rpart.plot", "randomForest", "caret"),
                 dependencies = TRUE)

library(rpart)
library(rpart.plot)
library(randomForest)
library(caret)
